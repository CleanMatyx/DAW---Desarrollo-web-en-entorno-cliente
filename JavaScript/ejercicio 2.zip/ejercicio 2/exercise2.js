"use strict";

const formRestaurant = document.getElementById("newRestaurant");
const imgPreview = document.getElementById("imgPreview");
const placesContainer = document.getElementById("placesContainer");
const daysError = document.getElementById("daysError");

formRestaurant.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = formRestaurant.name.value.trim();
    const description = formRestaurant.description.value.trim();
    const cuisine = formRestaurant.cuisine.value.trim();
    const days = Array.from(formRestaurant.days)
        .filter((i) => i.checked);
    const phone = formRestaurant.phone.value.trim();
    const image = formRestaurant.image.files[0];
    const nameRegex = /^[A-Za-z][A-Za-z\s]*$/;
    const phoneRegex = /^\d{9}$/;
    const withoutSpaceRegex = /^[A-Za-z][A-Za-z\s]+$/;
    
    function validateForm(formRestaurant, name, nameRegex, description, cuisine, days, daysError, phone, phoneRegex, image) {
        let isValid = true;
    
        isValid = validateField(formRestaurant.name, name, nameRegex) && isValid;
        isValid = validateField(formRestaurant.description, description, withoutSpaceRegex) && isValid;
        isValid = validateField(formRestaurant.cuisine, cuisine, withoutSpaceRegex) && isValid;
        isValid = validateDays(days, daysError) && isValid;
        isValid = validateField(formRestaurant.phone, phone, phoneRegex) && isValid;
        isValid = validateField(formRestaurant.image, image, null) && isValid;
    
        return isValid;
    }
    
    function validateField(field, value, regex) {
        if (!value || (regex && !regex.test(value))) { // si regex = null sólo comprueba que no esté el campo vacío
            field.classList.add("is-invalid");
            field.classList.remove("is-valid");
            return false;
        } else {
            field.classList.add("is-valid");
            field.classList.remove("is-invalid");
            return true;
        }
    }
    
    function validateDays(days, daysError) {
        if (days.length === 0) {
            daysError.classList.remove("d-none");
            return false;
        } else {
            daysError.classList.add("d-none");
            return true;
        }
    }
    
    const isValid = validateForm(formRestaurant, name, nameRegex, description, cuisine, days, daysError, phone, phoneRegex, image);

    // if (isValid) {
    //     //<div class="col">
    //     const colDiv = document.createElement("div");
    //     colDiv.classList.add("col");
    //     //<div class="card h-100 shadow">
    //     const cardDiv = document.createElement("div");
    //     cardDiv.classList.add("card", "h-100", "shadow");
    //     //<img class="card-img-top" src="IMAGE_BASE64">
    //     const img = document.createElement("img");
    //     img.classList.add("card-img-top");
    //     img.src = imgPreview.src;
    //     //<div class="card-body">
    //     const cardBodyDiv = document.createElement("div");
    //     cardBodyDiv.classList.add("card-body");
    //     //<h4 class="card-title">Nombre</h4>
    //     const h4 = document.createElement("h4");
    //     h4.classList.add("card-title");
    //     h4.textContent = name;
    //     //<p class="card-text">Descripción</p>
    //     const pDescription = document.createElement("p");
    //     pDescription.classList.add("card-text");
    //     pDescription.textContent = description;
    //     //<div class="card-text">
    //     const divDays = document.createElement("div");
    //     divDays.classList.add("card-text");
    //     //<small class="text-muted">
    //     const daysSmallbg = document.createElement("small");
    //     daysSmallbg.classList.add("text-muted");
    //     // <strong>Apertura: </strong>Lu, Ma, Mi, Ju, Vi, Sa, Do </small>
    //     const daysStrongBg = document.createElement("strong");
    //     daysStrongBg.textContent = "Apertura: ";
    //     daysSmallbg.appendChild(daysStrongBg);
    //     // Creo pequeño diccionario para darle valor reducido en inglés a los días abiertos
    //     const dayNames = {
    //         0: "Su",
    //         1: "Mo",
    //         2: "Tu",
    //         3: "We",
    //         4: "Th",
    //         5: "Fr",
    //         6: "Sa"
    //     };
    //     // Compruebo los días checked en el formulario y los muestro separados por comas
    //     const daysText = days.map((i) => dayNames[i.value]).join(", ");
    //     daysSmallbg.appendChild(document.createTextNode(daysText));
    //     // Creo el span y muestro cartel de Abierto(verde) o Cerrado(rojo) según el día actual
    //     const spanBadge = document.createElement("span");
    //     spanBadge.classList.add("badge", "ms-2");
    //     const today = new Date().getDay(); // 0 (Domingo) a 6 (Sábado)
    //     // <span class="badge ms-2 bg-success">Abierto</span>
    //     if (days.some(day => parseInt(day.value) === today)) {
    //         spanBadge.classList.add("bg-success");
    //         spanBadge.textContent = "Abierto";
    //     // <span class="badge ms-2 bg-danger">Cerrado</span>
    //     } else {
    //         spanBadge.classList.add("bg-danger");
    //         spanBadge.textContent = "Cerrado";
    //     }

    //     divDays.appendChild(daysSmallbg);
    //     divDays.appendChild(spanBadge);
    //     //<div class="card-text">
    //     const divPhone = document.createElement("div");
    //     divPhone.classList.add("card-text");
    //     //<small class="text-muted">
    //     const phoneSmall = document.createElement("small");
    //     phoneSmall.classList.add("text-muted");
    //     //<strong>Teléfono: </strong>
    //     const phoneStrong = document.createElement("strong");
    //     phoneStrong.textContent = "Teléfono: ";
    //     phoneSmall.appendChild(phoneStrong);

    //     phoneSmall.appendChild(document.createTextNode(phone));
    //     divPhone.appendChild(phoneSmall);
    //     //<div class="card-footer">
    //     const cardFooterDiv = document.createElement("div");
    //     cardFooterDiv.classList.add("card-footer");
    //     //<small class="text-muted">Tipo de cocina</small>
    //     const cuisineSmall = document.createElement("small");
    //     cuisineSmall.classList.add("text-muted");
    //     cuisineSmall.textContent = cuisine;

    //     //Añado la columna colDiv al placesContainer para mostrar la carta
    //     colDiv.appendChild(cardDiv);
    //     placesContainer.appendChild(colDiv);
    //     //Añado a la tarjeta los siguientes elementos
    //     cardDiv.appendChild(img);               //imagen
    //     cardDiv.appendChild(cardBodyDiv);       //cuerpo de la carta
    //     cardDiv.appendChild(cardFooterDiv);     //footer de la carta
    //     //Añado al cuerpo de la carta los siguientes elementos
    //     cardBodyDiv.appendChild(h4);            //nombre
    //     cardBodyDiv.appendChild(pDescription);  //descripcion
    //     cardBodyDiv.appendChild(divDays);       //dias apertura
    //     cardBodyDiv.appendChild(divPhone);      //telefono
    //     //Añado cuisineSmall al pie de la carta
    //     cardFooterDiv.appendChild(cuisineSmall);

    //     //Vacío los campos del formulario
    //     formRestaurant.reset();
    //     imgPreview.src = "";
    //     imgPreview.classList.add("d-none");
    //     //Invalido los campos
    //     formRestaurant.name.classList.remove("is-valid");
    //     formRestaurant.description.classList.remove("is-valid");
    //     formRestaurant.cuisine.classList.remove("is-valid");
    //     formRestaurant.phone.classList.remove("is-valid");
    //     formRestaurant.image.classList.remove("is-valid");
    // }

    if (isValid) {
        const clone = cFillTemplate(imgPreview, name, description, days, phone, cuisine);
        placesContainer.appendChild(clone);
        resetForm(formRestaurant, imgPreview);
    }

    function cFillTemplate(imgPreview, name, description, days, phone, cuisine) {
        const template = document.getElementById('restaurant-card-template');
        const clone = template.content.cloneNode(true);
    
        clone.querySelector('.card-img-top').src = imgPreview.src;
        clone.querySelector('.card-title').textContent = name;
        clone.querySelector('.card-text').textContent = description;
    
        const daysText = getDaysText(days);
        clone.querySelector('.days-text').textContent = daysText;
    
        const spanBadge = clone.querySelector('.badge');
        updateBadge(spanBadge, days);
    
        clone.querySelector('.phone-text').textContent = phone;
        clone.querySelector('.cuisine-text').textContent = cuisine;
    
        return clone;
    }
    
    function getDaysText(days) {
        const dayNames = {
            0: "Su",
            1: "Mo",
            2: "Tu",
            3: "We",
            4: "Th",
            5: "Fr",
            6: "Sa"
        };
        return days.map((i) => dayNames[i.value]).join(", ");
    }
    
    function updateBadge(spanBadge, days) {
        const today = new Date().getDay();
        if (days.some(day => parseInt(day.value) === today)) {
            spanBadge.classList.add("bg-success");
            spanBadge.textContent = "Abierto";
        } else {
            spanBadge.classList.add("bg-danger");
            spanBadge.textContent = "Cerrado";
        }
    }
    
    function resetForm(formRestaurant, imgPreview) {
        formRestaurant.reset();
        imgPreview.src = "";
        imgPreview.classList.add("d-none");
        formRestaurant.name.classList.remove("is-valid");
        formRestaurant.description.classList.remove("is-valid");
        formRestaurant.cuisine.classList.remove("is-valid");
        formRestaurant.phone.classList.remove("is-valid");
        formRestaurant.image.classList.remove("is-valid");
    }
});

formRestaurant.image.addEventListener('change', event => {
    let file = event.target.files[0];
    let reader = new FileReader();
    if (file) reader.readAsDataURL(file);
    reader.addEventListener('load', e => {
        imgPreview.src = reader.result;
        imgPreview.classList.remove("d-none");
    });
});